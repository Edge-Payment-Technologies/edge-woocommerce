( () => {
	'use strict';
	const e = window.wp.i18n,
		t = window.wc.wcBlocksRegistry,
		n = window.wp.htmlEntities,
		a = window.wc.wcSettings,
		s = window.wp.element,
		r = ( 0, a.getSetting )( 'edge_data', {} ),
		d = ( 0, e.__ )( 'Edge Payments', 'edge-gateway' ),
		o = ( 0, n.decodeEntities )( r.title ) || d;
	let i,
		c = '',
		m = ! 1;
	const p = () => (
			( 0, s.useEffect )( () => {
				const e = document.createElement( 'script' );
				return (
					( e.src =
						'https://assets.tryedge.io/assets/js/edge-0082aa6231d2034eb9d5c489d74c41bb.js?vsn=d' ),
					( e.onload = y ),
					document.body.appendChild( e ),
					() => {}
				);
			}, [] ),
			( 0, s.createElement )( 'div', { id: 'card-fields' } )
		),
		y = async () => {
			const e = await fetch( r.payment_demand_url, {
					method: 'POST',
					credentials: 'same-origin',
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded',
					},
					body: new URLSearchParams( {
						action: 'edge_create_payment_demand',
						nonce: r.payment_demand_nonce,
					} ),
				} ),
				t = await e.json();
			if ( ! e.ok || ! t.success || ! t.data?.payment_demand_id )
				throw new Error(
					t.data?.message || 'Unable to initialize Edge Payments.'
				);
			( c = t.data.payment_demand_id ),
				( i = new Edge( r.publishable_key, { formFactor: 'inputs' } ) ),
				i.on( 'payment_method_changed', ( e ) => {
					m = Boolean( e.detail?.ready );
				} );
			const n = i.mountPaymentForm( 'card-fields', c );
			( n.style.border = '0' ), ( n.style.boxShadow = 'none' );
		},
		l = ( e ) => {
			const {
					billing: t,
					shippingData: n,
					eventRegistration: a,
					emitResponse: d,
				} = e,
				{ onPaymentSetup: o } = a,
				y = t?.billingAddress || {},
				l = n?.shippingAddress || y;
			return (
				( 0, s.useEffect )( () => {
					const e = o( async () => {
						if ( i && c && m ) {
							try {
								await ( async ( e, t ) => {
									const n = await fetch(
											r.payment_demand_url,
											{
												method: 'POST',
												credentials: 'same-origin',
												headers: {
													'Content-Type':
														'application/x-www-form-urlencoded',
												},
												body: new URLSearchParams( {
													action: 'edge_prepare_payment_demand',
													nonce: r.payment_demand_nonce,
													payment_demand_id: c,
													billing_address:
														JSON.stringify( e ),
													shipping_address:
														JSON.stringify( t ),
												} ),
											}
										),
										a = await n.json();
									if ( ! n.ok || ! a.success )
										throw new Error(
											a.data?.message ||
												'Unable to prepare Edge Payments.'
										);
								} )( y, l ),
									await i.verifyPaymentMethod();
							} catch ( e ) {
								return {
									type: d.responseTypes.ERROR,
									message:
										'We could not verify your card. Please check your card details and try again.',
								};
							}
							return {
								type: d.responseTypes.SUCCESS,
								meta: {
									paymentMethodData: { payment_demand_id: c },
								},
							};
						}
						return {
							type: d.responseTypes.ERROR,
							message: 'Please enter your card information.',
						};
					} );
					return () => {
						e();
					};
				}, [
					d.responseTypes.ERROR,
					d.responseTypes.SUCCESS,
					y,
					o,
					l,
				] ),
				( 0, s.createElement )(
					s.Fragment,
					null,
					( 0, s.createElement )( 'div', {
						dangerouslySetInnerHTML: { __html: r.description },
					} ),
					( 0, s.createElement )( p )
				)
			);
		},
		w = {
			name: 'edge',
			label: ( 0, s.createElement )( ( e ) => {
				const { PaymentMethodLabel: t } = e.components;
				return ( 0, s.createElement )( t, { text: o } );
			} ),
			content: ( 0, s.createElement )( l ),
			edit: ( 0, s.createElement )( l ),
			canMakePayment: () => ! 0,
			ariaLabel: o,
			supports: { features: r.supports },
			currencies: [ 'USD' ],
			supportsRecurring: ! 0,
		};
	( 0, t.registerPaymentMethod )( w );
} )();
